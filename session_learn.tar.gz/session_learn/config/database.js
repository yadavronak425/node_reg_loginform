const Sequelize = require('sequelize');

const sequelize = new Sequelize('node_test','root','', {
    logging: false,
    host: '192.168.2.29',
    dialect: 'mysql'
});

sequelize.authenticate()
        .then(() =>{console.log("Connected to database");})
        .catch((err) =>{ console.log("Error",err);})

        module.exports = sequelize;