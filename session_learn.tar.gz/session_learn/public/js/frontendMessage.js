$(document).ready(function(){
    setTimeout(function(){
         $(".warning_msg").fadeOut() 
        }, 5000);
});