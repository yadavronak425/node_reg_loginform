const express = require('express');
const router = express.Router();


const regValidate = require('../apps/middleware/register.js');
const userController = require('../apps/controllers/userController.js');


//Login Page
 router.get('/login', (req, res) =>{
    res.render("login.html", {message: req.flash('successMessage')});
 });
 //Login Page Handler
 router.post('/login', (req, res) =>{
    res.send("Inside Login Handler Page");
 });
 //Register Page
router.get('/register', (req, res) =>{
    res.render("registration.html", {message: req.flash('errorMessage'), vError: req.flash('vError')});
 });
//Register Page Handler
//router.post('/register', userController.register);
router.post('/register', regValidate.regCheck, userController.register);

 module.exports = router;