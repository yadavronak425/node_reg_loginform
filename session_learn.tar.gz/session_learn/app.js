const express = require('express');
//const parseurl = require('parseurl');
const session = require('express-session');
const bodyParser = require('body-parser');
const nunjucks = require('nunjucks');
const flash = require('req-flash');
const expressValidator = require('express-validator');

const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
//const mysql2 = require('mysql2');

const app = express();
var port = process.env.PORT || 8000;
// Static path
app.use(express.static(__dirname + '/public'));

//configuration of nunjucks
nunjucks.configure('./apps/views', {
    autoescape: true,
    express: app
});
//configuration of body-parser
app.use(bodyParser.urlencoded({extended: false }));

//configuration of Connect-flash-plus
app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: false
}));
app.use(flash());
app.use(expressValidator());
//configuration of passport
app.use(passport.initialize());
app.use(passport.session());

app.set('view engine', 'html');

app.get('/',(req, res) =>{
    res.render('index.html');
})
//Router for User
app.use('/user', require('./routes/router.js'));





app.listen(port,() => {console.log("Server connected to localhost "+port);});