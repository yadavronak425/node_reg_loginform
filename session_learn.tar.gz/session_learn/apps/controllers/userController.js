const userDefine = require('../models/userModel.js');


module.exports.register = function(req, res){
  let userName = req.body.username;
  let userPw = req.body.password;
  if(userName != '' && userPw !=''){
            userDefine.userModel.userDf.create({username: userName, password: userPw})
                 .then((created) =>{
                    req.flash('successMessage', 'Successfully Registered');
                     res.redirect('/user/login');
                    })
                 .catch((err) =>{
                     console.log('Error',err);
                     req.flash('errorMessage', 'Sorry, Something went wrong');
                     res.redirect('/user/register');
                   })
        } else{
            req.flash('errorMessage', 'All fields are required.');
            return res.redirect('/user/register');
        }
}
