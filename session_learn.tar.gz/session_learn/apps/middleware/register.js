const { check, validationResult } = require('express-validator/check');

exports.regCheck = (req, res, next) =>{
    req.checkBody('username').isLength({min: 5}).withMessage('Name must have more than 5 characters'),
    req.checkBody('username').isAlphanumeric().withMessage('Only Alphanumeric allowed'),
    req.checkBody('password').isLength({ min: 5 }).withMessage('Password must have more than 5 characters');

    var errors = req.validationErrors();

	   	if(errors){
            req.flash('vError',errors);
            res.redirect('/user/register');
	   	}else{	   		
            next();
	   	}
}

