const Sequelize = require('sequelize');
var db = require('../../config/database.js');

var userModel = db.define('user_passport', {
    username: {
        type: Sequelize.STRING,
              allowNull: false
    },
    password: {
        type: Sequelize.STRING,
            allowNull: false
    }
},{
    freezeTableName: true,
    createdAt: false,
    updatedAt: false,
});
userModel.removeAttribute('id');

exports.userModel = {userDf: userModel}